# phaser3-lab
This is a laboratory to experiment phaser3 game framework
